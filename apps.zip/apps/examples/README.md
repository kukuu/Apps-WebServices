# axios examples

To run the examples:

1. `npm install`
2. `grunt build`
3. `npm run examples`
4. [http://localhost:3020](http://localhost:3020)
