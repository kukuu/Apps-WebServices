describe('basicAuth without btoa polyfill', function () {
  setupBasicAuthTest();
});
